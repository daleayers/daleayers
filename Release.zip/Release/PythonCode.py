import re
import string
import os

#Opens the G.txt file, reads it creates a dictionary, uses a for loop & .strip() to take the /n off the end, 
#Checks to see if string has already been created if not it adds it to the dictonary and if its already there 
#it adds 1, then use a for loop to print everything in the file.
def ListItem():
    filename = "G.txt"
    with open(filename, "r") as file: #open file and read it using r
        contents = file.read().split()
        my_dict = {} #create dictonary 
        for item in contents:
            item = item.strip()
            if item not in my_dict.keys():
                my_dict[item] = 1  # creates a new key-value pair
            else:
                my_dict[item] += 1
        for k, v in my_dict.items(): #print using for loop
            print(k, v)

#Passes a user string through as an argument from c++ open the G.txt file. then do the same thing as in our previous
#function using .strip() to remove /n Then because we are using python we can use the method.count() to count the amount of times
#the string is in the file. 
def ItemSearch(v):
    filename = "G.txt"
    with open(filename, "r") as file:
        lines = file.readlines()
        lines = [line.strip() for line in lines]  # This achieves the same as a for loop

        # for i in range(len(lines)):
        #		lines[i] = lines[i][:-1] # This line just removes the last character of the string

        amount = lines.count(v)
        print(v, amount)

#Open the G.txt file, read it, split it, strip it add it to the dictonary 
#Now create a file named frequency.dat using w now instead of printing we can .write() to our file.
def GroceryGraph():
    filename = "G.txt"
    with open(filename, "r") as file:
        contents = file.read().split()
        my_dict = {} #create dictonary 
        for item in contents:
            item = item.strip() #take off /n
            if item not in my_dict.keys():
                my_dict[item] = 1  # creates a new key-value pair
            else:
                my_dict[item] += 1
        

        with open("frequency.dat", "w") as outfile:
            for k, v in my_dict.items():
                outfile.write("{} {}\n".format(k, v))#write to file using for loop 
    



    


    


        
        
